/* Global Variables */

//const { json } = require("body-parser");

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1+'.'+ d.getDate()+'.'+ d.getFullYear();
const ApiKey="7031a147d31430ee2ff812388f980d07";

const generateBtn = document.getElementById('generate');

generateBtn.addEventListener('click',async ()=>{
    const zipCode= document.getElementById('zip').value
    const feelings= document.getElementById('feelings').value
    
    if(!zipCode ||!feelings){
      alert('Please feel all requirements')}
  
    
    // fetch API
    const apiURl=`https://api.openweathermap.org/data/2.5/weather?zip=${zipCode},us&appid=${ApiKey}`
    const res = await fetch(apiURl)
    const response= await res.json()
    const temp =response.main.temp;

 

    //Post route
    const data ={date: newDate,temp,feelings}
    const options=
    {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    }
  await fetch('/postTemp', options);
  

 // get route //updating UI
 

  
const getDataBack = await fetch('/getTemp')

const dataBack=await getDataBack.json();
console.log(dataBack);

document.getElementById("date").textContent="Today is:"+dataBack.date;
document.getElementById("temp").textContent=`Tempreture here at ${dataBack.temp}`;
document.getElementById("content").textContent="You feeling "+dataBack.feelings;



})

